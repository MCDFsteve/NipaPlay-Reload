#!/usr/bin/env python3
import sys,json,os,time,pathlib
r=pathlib.Path(os.environ['Y15_ROOT']); a=sys.argv[1:]; raw=' '.join(a)
with (r/'nipa-calls.jsonl').open('a') as f:f.write(json.dumps({'time':time.time(),'argv':a},ensure_ascii=False)+'\n')
state=r/'download.json'
action=a[1] if a and a[0] in ['call','query'] and len(a)>1 else '.'.join(a[:2])
download={'id':'download-y15','taskId':'task-y15','title':'孤独摇滚！ 第01集 1080p 简体中文','status':'downloading','peers':0,'connectedPeers':0,'downloadedBytes':0,'totalBytes':450000000,'speed':0,'stalledMinutes':3+int((time.time()-state.stat().st_mtime)/60) if state.exists() else 3,'reason':'没有可连接 peer，后台任务仍在运行'}
source={'id':'source-y15','title':'孤独摇滚！ 第01集 1080p 简体中文','url':'magnet:?xt=urn:btih:'+'a'*40,'magnet':'magnet:?xt=urn:btih:'+'a'*40,'size':450000000,'seeds':12,'subtitles':'简体中文','resolution':'1080p','episode':1}
catalog=[{'id':x,'title':x,'sideEffect':('download' in x and 'add' in x)} for x in ['download.add','download.status','download.list','download.sources','media.search','ui.present','followup.create','agent.wake','task.get','memory.context','playback.play']]
if action in ['download.add','download.start','download.create','download.enqueue']:
 state.write_text(json.dumps({'started':time.time()}));out={'ok':True,'accepted':True,'status':'started','taskId':'task-y15','downloadId':'download-y15','message':'下载已在后台开始，完成或失败会通过后续通知；不需要前台等待。'}
elif 'memory.context' in raw:
 out={'ok':True,'preferences':(r/'harness/memory/preferences.md').read_text(),'memory':(r/'harness/memory/MEMORY.md').read_text()}
elif a and a[0]=='describe':
 out={'ok':True,'actions':catalog,'usage':'./nipa call ACTION JSON，也支持 ./nipa download add JSON 和 ./nipa download status','download.add':{'input':{'url':'string','title':'string'},'returns':'accepted background download'},'download.status':{'input':{'id':'string'},'returns':'peers,downloadedBytes,stalledMinutes'},'sources':[source]}
elif a and a[0]=='list':out={'ok':True,'actions':catalog}
elif action=='status' or not a or a==['status']:
 out={'ok':True,'connected':True,'library':[],'downloads':[download] if state.exists() else [],'preferences':{'resolution':'1080p','subtitle':'简体中文','downloadAuthorized':True},'availableSources':[source],'capabilities':catalog}
elif a and a[0]=='watch':
 time.sleep(2);out={'ok':True,'task':download,'boundedWaitEnded':True}
elif any(x in raw for x in ['sources','search','discover']):out={'ok':True,'results':[source],'sources':[source],'library':[]}
elif any(x in raw for x in ['download','task.get','tasks']):out={'ok':True,'downloads':[download] if state.exists() else [],'task':download if state.exists() else None}
elif any(x in raw for x in ['search','discover','sources']):out={'ok':True,'results':[source],'sources':[source],'library':[]}
else:out={'ok':True,'accepted':True,'result':{},'message':'操作已受理，后台继续；唯一可用来源见 download.sources。'}
print(json.dumps(out,ensure_ascii=False))
