import json,pathlib,hashlib,gzip,tarfile,datetime,os,tomllib,re,subprocess
from analyze import ROOT,sha,analyze_run,request_stats
REPO=pathlib.Path('/Users/sakiko/Desktop/NipaPlay-Reload')
DEST=REPO/'docs/next/evidence/y15';DEST.mkdir(parents=True,exist_ok=True)
j=json.loads((ROOT/'measurements.json').read_text())
j['seed_sha256']=sha(ROOT/'seed/AGENTS.md')
j['captures']={k:v for k,v in j['captures'].items() if k.startswith('capture-final-')}
clean=[x for x in j['behavior'] if not x.get('running') and x.get('order_before_query') and not x['errors'] and not x['http_errors']]
dirty=[x for x in j['behavior'] if not x.get('running') and (x['errors'] or x['http_errors'])]
noorder=[x for x in j['behavior'] if not x.get('running') and not x.get('order_before_query') and not x['errors'] and not x['http_errors']]
j['counts']={'formal_attempts':len(j['behavior']),'clean_in_download_steer':len(clean),'provider_error_attempts':len(dirty),'no_order_clean':len(noorder)}
j['probes']=[]
for p in sorted((ROOT/'runs').glob('probe-*')):
    f=p/'protocol-result.json'
    if not f.exists():continue
    d=json.loads(f.read_text());safe={k:v for k,v in d.items() if k not in ['initial_state','resumed_state','resumed_messages','state','session_stats']}
    safe['name']=p.name;safe['raw_result_sha256']=sha(f)
    if 'resumed_messages' in d:safe['resumed_message_count']=len(d['resumed_messages'].get('data',{}).get('messages',[]))
    j['probes'].append(safe)
j['excluded_exploration']=[{'name':p.name,'reason':'pre-final fixture/seed or isolation; not included in formal comparison','seed_sha256':sha(p/'harness/AGENTS.md'),'result_sha256':sha(p/'result.json') if (p/'result.json').exists() else None} for p in sorted((ROOT/'runs').glob('*')) if p.is_dir() and p.name.startswith(('trial-','behavior-')) and not p.name.startswith('behavior-final-')]

sources={'retrieved_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'runtimes':[]}
for n,package in [('codex','@openai/codex'),('pi','@earendil-works/pi-coding-agent'),('dsh','@deepseek-ai/dsh')]:
    p=ROOT/(n+'-install')/'node_modules'/package/'package.json';d=json.loads(p.read_text())
    mpath=ROOT/(n+'-npm-metadata.json');meta=json.loads(mpath.read_text()) if mpath.exists() else {}
    row={'name':package,'version':d['version'],'license':d.get('license'),'engines':d.get('engines'),'repository':d.get('repository'),'package_json_sha256':sha(p),'installed_logical_bytes':sum(f.stat().st_size for f in (ROOT/(n+'-install')).rglob('*') if f.is_file() and not f.is_symlink()),'published_at':meta.get('time',{}).get(d['version']),'dist':{k:v for k,v in meta.get('dist',{}).items() if k in ['integrity','shasum','unpackedSize','tarball']}}
    rp=ROOT/(n+'-release.json');gp=ROOT/(n+'-github.json')
    if rp.exists():
        rel=json.loads(rp.read_text());row['release']={'url':rel.get('html_url'),'tag':rel.get('tag_name'),'published_at':rel.get('published_at'),'prerelease':rel.get('prerelease'),'assets':[{'name':a['name'],'bytes':a['size'],'url':a['browser_download_url'],'digest':a.get('digest')} for a in rel.get('assets',[])]}
    if gp.exists():
        gh=json.loads(gp.read_text());row['maintenance']={k:gh.get(k) for k in ['html_url','archived','pushed_at']}
    sources['runtimes'].append(row)
sources['pi_native_asset']={'header':json.loads((ROOT/'pi-asset-header.json').read_text()),'probe':json.loads((ROOT/'pi-native-result.json').read_text()),'archive_sha256':sha(ROOT/'pi-darwin-arm64.tar.gz'),'archive_bytes':(ROOT/'pi-darwin-arm64.tar.gz').stat().st_size,'rpc_capture_name':'capture-final-pi-native'}
expected=next(a.get('digest') for a in json.loads((ROOT/'pi-release.json').read_text())['assets'] if a['name']=='pi-darwin-arm64.tar.gz')
sources['pi_native_asset']['upstream_digest']=expected
sources['pi_native_asset']['digest_matches']=expected=='sha256:'+sources['pi_native_asset']['archive_sha256'] if expected else None
sources['source_file_hashes']=[]
for pattern in ['pi-install/node_modules/@earendil-works/pi-coding-agent/docs/{none}','dsh-install/node_modules/@deepseek-ai/dsh-*/README.md']:
    for p in ROOT.glob(pattern):sources['source_file_hashes'].append({'local_path':str(p.relative_to(ROOT)),'bytes':p.stat().st_size,'sha256':sha(p)})
for n in ['cli.md','rpc.md','rpc-commands.md','compaction.md','extensions.md','windows.md','models.md']:
    p=ROOT/'pi-install/node_modules/@earendil-works/pi-coding-agent/docs'/n;sources['source_file_hashes'].append({'local_path':str(p.relative_to(ROOT)),'bytes':p.stat().st_size,'sha256':sha(p)})

def write_gz(name,data):
    raw=json.dumps(data,ensure_ascii=False,indent=2).encode();(DEST/name).write_bytes(gzip.compress(raw,mtime=0))
write_gz('measurements.json.gz',j);write_gz('sources.json.gz',sources)
scripts=['lab.py','fake_nipa.py','batch.py','analyze.py','protocol.py','memory_probe.py','dsh_cold.py','replacements.py','last_trial.py','pi_last.py','package_evidence.py','dsh-install/y15-bridge.mjs']
with tarfile.open(DEST/'lab-scripts.tar.gz','w:gz') as tf:
    for n in scripts:tf.add(ROOT/n,arcname=n,recursive=False)

def short(x):return x['name'].replace('behavior-final-','')
def s(v):return '—' if v is None else f'{v:.1f}'
lines=['**正式尝试共 18 次：Codex 4、精简 Codex 6、pi 5、DSH 3。** 其中 11 次同时满足已下单、下载中插话、无提供方错误；另有 6 次受 429 污染、1 次未下单。pi 只有两次无错误的该场景样本，不能声称完成了三次无错误验收。下面先列可直接比较的观测，失败不隐藏。','', '| 样本 | 插话入模秒 | 首次可见文字秒 | 下单至首次回合结束秒 | 工具调用：总数/插话后 |','|---|---:|---:|---:|---:|']
for x in clean:lines.append(f"| {short(x)} | {s(x['delivery_seconds'])} | {s(x['first_visible_seconds'])} | {s(x['post_order_to_first_terminal_seconds'])} | {x['total_tool_calls_wire']}/{x['tool_calls_after_query']} |")
lines+=['','这些成功样本在下单后 2 秒插话时都还在运行，随后才结束回合；没有把后台 BT 完成作为本轮必需条件一直等到超时。可观察到的区别是额外查状态/查来源与出声的先后。各组并未形成“pi 必然立刻结束、Codex 必然守住下载”的分界。','', '| 同一工作回合分账 | 初始阶段 input/output token | 已消费插话后 input/output token |','|---|---:|---:|']
for x in clean:
    a=x['phase_tokens']['initial'];b=x['phase_tokens']['after_query_consumed'];lines.append(f"| {short(x)} | {a['input_tokens']:,} / {a['output_tokens']:,} | {b['input_tokens']:,} / {b['output_tokens']:,} |")
lines+=['','排除项仍属于已执行的正式尝试：','', '| 样本 | 事实 | 首次可见文字秒 |','|---|---|---:|']
for x in noorder:lines.append(f"| {short(x)} | 初始回合正常结束但只请用户选来源，没有下单；问进度变成新回合 | {s(x['first_visible_seconds'])} |")
for x in dirty:lines.append(f"| {short(x)} | 提供方 429，{'插话前已下单' if x['order_before_query'] else '插话前没有完成下单'}；不参与延迟/优劣比较 | {s(x['first_visible_seconds'])} |")
lines+=['','429 原文指提供方上游候选账号限额或禁用；没有据此推断 pi 或精简提示本身会触发限额。初轮并行四组，补样改为顺序，仍有 429。原始失败计量、所有逐请求 usage 与重试都保留在压缩证据；未返回 usage 的失败请求不补造 token。']
report=REPO/'docs/next/Y15_REPORT.md';text=report.read_text().replace('<!-- Y15_BEHAVIOR_TABLE -->','\n'.join(lines))
text=text.replace('<!-- Y15_ARTIFACTS -->','''- [计量、18 次正式尝试、协议探针与原件哈希](evidence/y15/measurements.json.gz)。
- [发布版本、资产、安装体积、来源文件哈希](evidence/y15/sources.json.gz)。
- [原创实验脚本压缩包](evidence/y15/lab-scripts.tar.gz) 与 [证据说明](evidence/y15/README.md)。

解压到实验目录后，可用 `python3 analyze.py` 从本地原件重算；不要把真实凭据填进脚本或归档。脚本中的路径、固定版本与隔离条件见证据说明。''')
text=text.replace('/packages/session/system-prompt/README.md','/packages/core/system-prompt/README.md')
report.write_text(text)
(DEST/'README.md').write_text('''# Y15 压缩证据

`measurements.json.gz` 是原创计量与脱敏事件摘要：首请求仅保留长度、角色布局、工具名、估算 token 和原件 SHA-256；不含第三方系统提示/工具 schema 原文。行为部分保留 18 次正式尝试和全部提供方失败，另列排除的预跑。模型可见输出仅保留 assistant 正文，不含原始思考。

`sources.json.gz` 是公开 npm/GitHub 发布元数据与本机来源文件哈希，不复制第三方源码或 SDK。许可、平台与前次接入研究见 ../../research/ACP.md、../../research/AGENT_RUNTIMES.md。

`lab-scripts.tar.gz` 仅含本任务原创脚本。原始请求、SSE、会话、第三方文件仍在 `~/.nipa-next/y15/`。实验原件为审计存档，不要直接覆盖运行目录。复现须先按报告版本本地安装（所有 cache/tmp/home 指向实验根），将脚本中的实验 ROOT/REPO 改成自己的路径，并准备该报告指定哈希的 AGENTS.md。macOS 正式实验使用 sandbox-exec；不是跨平台测试脚本。

假端点捕获不消耗真实模型额度。`lab.py behavior ...` 会读取用户 config.toml 的 cpa provider 并消耗真实额度；父转发器只在内存读取真实地址/key，子 agent 仅得到 loopback 和假 key。切勿复制真实配置进仓库。

token 估算是 tiktoken o200k_base 替代计数，非 DeepSeek 官方账单；正式行为 token 来自 Responses usage，缓存输入未扣除。provider 失败没有 usage 时不补估。

正式行为组 AGENTS 哈希为 131a9e869dcd5f3b8dde550a0969ce019d95353cbf7de307f2c5f54c01705a36。旧首请求和预跑是另一版本，不用于报告首请求表及正式行为对比。
''')
active=[]
for line in subprocess.check_output(['ps','-axo','pid=,ppid=,comm=,args='],text=True).splitlines():
    fields=line.strip().split(None,3)
    if len(fields)!=4:continue
    command=fields[3]
    if str(ROOT) in command and any(n in command for n in ['/lab.py','/batch.py','/protocol.py','/memory_probe.py','/dsh_cold.py','/replacements.py','/last_trial.py','/pi_last.py','/codex-install/node_modules/','/pi-install/node_modules/','/dsh-install/node_modules/','/pi-native/pi']) and not any(n in command for n in ['python3 - <<','/bin/zsh -lc']):active.append({'pid':int(fields[0]),'executable':fields[2]})
assert not active,active
checks={'checked_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'active_experiment_processes':active,'formal_seed_consistent':all(sha(ROOT/'runs'/x['name']/'harness/AGENTS.md')==j['seed_sha256'] for x in j['behavior']),'report_sha256':sha(report),'artifacts':[{'path':str(p.relative_to(REPO)),'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(DEST.iterdir()) if p.is_file() and p.name!='checks.json.gz'],'counts':j['counts'],'secrets_found':[]}
cfg=tomllib.loads((pathlib.Path.home()/'.codex/config.toml').read_text());provider=cfg['model_providers']['cpa'];secrets=[provider.get('experimental_bearer_token',''),provider.get('base_url',''),provider.get('model_catalog_url','')]
for p in [report,*DEST.iterdir()]:
    if not p.is_file():continue
    chunks=[p.read_bytes()]
    if p.name.endswith('.json.gz'):chunks.append(gzip.decompress(p.read_bytes()))
    if p.name.endswith('.tar.gz'):
        with tarfile.open(p) as tf:chunks.extend(tf.extractfile(m).read() for m in tf.getmembers() if m.isfile())
    if any(s and any(s.encode() in b for b in chunks) for s in secrets):checks['secrets_found'].append(str(p.relative_to(REPO)))
assert not checks['secrets_found'],'private configuration appeared in artifacts'
write_gz('checks.json.gz',checks)
print(json.dumps({'counts':j['counts'],'artifact_bytes':[(p.name,p.stat().st_size) for p in DEST.iterdir()],'secret_matches':len(checks['secrets_found'])},ensure_ascii=False))
