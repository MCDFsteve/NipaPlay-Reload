import asyncio,json,time
from lab import ROOT,prepare,Endpoint,Agent
async def one(kind,mode):
    out,work=prepare(f'probe-{kind}-{mode}');ep=Endpoint(out);ep.scenario='tools';a=Agent(kind,out,work,ep)
    result={'kind':kind,'mode':mode}
    try:
        await a.start();await a.prompt('Y15_FIRST')
        for _ in range(150):
            if any((x['event'].get('type')=='tool_execution_start') or (x['event'].get('params',{}).get('event',{}).get('type')=='tool/call') for x in a.events):break
            await asyncio.sleep(.02)
        result['injection_time']=time.time()
        if mode=='steer':result['receipt']=await a.prompt('Y15_STEER_MARKER',steer=True)
        elif mode=='follow_up':result['receipt']=await a.rpc('follow_up',{'message':'Y15_FOLLOWUP_MARKER'})
        else:
            result['queue_receipt']=await a.rpc('steer',{'message':'Y15_CLEARED_MARKER'})
            result['cleared']=await a.rpc('clear_queue');result['abort']=await a.rpc('abort')
        for _ in range(200):
            if not a.active:break
            await asyncio.sleep(.025)
        result['requests']=len(ep.requests);result['request_summaries']=[]
        for r in ep.requests:
            s=json.dumps(r['body'],ensure_ascii=False)
            result['request_summaries'].append({'n':r['n'],'seconds_from_inject':round(r['time']-result['injection_time'],3),'steer_marker':'Y15_STEER_MARKER' in s,'followup_marker':'Y15_FOLLOWUP_MARKER' in s,'cleared_marker':'Y15_CLEARED_MARKER' in s,'tool_output':'Y15_TOOL_DONE' in s})
        result['event_types']=[x['event'].get('type',x['event'].get('method')) for x in a.events]
        if kind=='pi':
            result['state']=await a.rpc('get_state');result['session_stats']=await a.rpc('get_session_stats')
        else:result['session_id']=a.sid
    except Exception as e:result['error']=repr(e)
    finally:
        if hasattr(a,'p'):await a.stop()
        ep.close()
    (out/'protocol-result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print(kind,mode,result.get('requests'),result.get('error'),flush=True)
async def main():
    for kind,mode in [('pi','steer'),('pi','follow_up'),('pi','abort_clear'),('dsh','steer')]:await one(kind,mode)
asyncio.run(main())
