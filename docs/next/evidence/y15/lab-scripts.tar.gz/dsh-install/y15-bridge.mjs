import { HarnessSdkJsonRpcServer } from '@deepseek-ai/dsh-sdk-jsonrpc-server';
import { JsonRpcLineTransport } from '@deepseek-ai/dsh-sdk-protocol';
import { createUserMessage } from '@deepseek-ai/dsh-llm';
export const name='y15-control-bridge';
export const inject=['agents','workingDirectory'];
export function apply(ctx) {
  const transport=new JsonRpcLineTransport(process.stdin,process.stdout);
  const server=new HarnessSdkJsonRpcServer(ctx,transport,{});
  transport.onRequest(async(method,params)=>{
    if(method==='initialize') await ctx.get('loader')?.await();
    if(method==='session/steer') {
      const agent=ctx.agents.get(params.sessionId);
      if(!agent) throw new Error('No active agent for session');
      const message=createUserMessage({content:params.contentBlocks,source:{kind:'user'}});
      agent.steer(message);
      return {messageId:message.id,delivery:'next-step'};
    }
    if(method==='session/cancel') {
      const agent=ctx.agents.get(params.sessionId);
      if(!agent) throw new Error('No active agent for session');
      agent.cancel({kind:'user'});
      return {};
    }
    const result=await server.handleRequest(method,params);
    if(method==='shutdown')setImmediate(async()=>{await ctx.root.fiber.dispose();process.exit(0);});
    return result;
  });
  ctx.effect(()=>{transport.start();return async()=>{await server.shutdown();transport.close();};});
}
