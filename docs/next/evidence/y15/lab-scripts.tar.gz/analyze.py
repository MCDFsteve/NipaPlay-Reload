import pathlib,json,hashlib,sys,os,re,gzip,datetime
ROOT=pathlib.Path.home()/'.nipa-next/y15'
sys.path.insert(0,str(ROOT/'python-libs'))
os.environ['TIKTOKEN_CACHE_DIR']=str(ROOT/'tiktoken-cache')
import tiktoken
ENC=tiktoken.get_encoding('o200k_base')
def tokens(s):return len(ENC.encode(s,disallowed_special=()))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def content(x):
    if isinstance(x,str):return x
    if isinstance(x,list):return '\n'.join(i.get('text','') for i in x if isinstance(i,dict))
    return ''
def tools_list(tools):
    out=[]
    for x in tools:
        if x.get('type')=='namespace':out.extend(x.get('name','')+'.'+a.get('name','') for a in x.get('tools',[]))
        else:out.append(x.get('name') or x.get('function',{}).get('name') or x.get('type'))
    return out
def request_stats(p):
    r=json.loads(p.read_text());b=r['body'];ms=b.get('input',b.get('messages',[]));ins=b.get('instructions','');dev=[content(x.get('content')) for x in ms if isinstance(x,dict) and x.get('role') in ['system','developer']]
    system=ins+'\n'.join(dev)
    items=[{'role':m.get('role'), 'type':m.get('type'),'chars':len(content(m.get('content'))),'utf8_bytes':len(content(m.get('content')).encode()),'estimate_tokens':tokens(content(m.get('content'))),'agents_injected':'# NipaPlay Harness' in content(m.get('content'))} for m in ms if isinstance(m,dict)]
    tooltext=json.dumps(b.get('tools',[]),ensure_ascii=False,separators=(',',':'))
    text=ins+'\n'.join(content(m.get('content')) for m in ms if isinstance(m,dict))+tooltext
    return {'raw_sha256':sha(p),'seed_sha256':sha(p.parent/'harness/AGENTS.md'),'request_path':r['path'],'body_bytes':len(json.dumps(b,ensure_ascii=False,separators=(',',':')).encode()),'instructions_chars':len(ins),'instructions_estimate_tokens':tokens(ins),'system_developer_chars':len(system),'system_developer_estimate_tokens':tokens(system),'system_developer_without_seed_chars':len(system.replace((p.parent/'harness/AGENTS.md').read_text(),'')),'message_layout':items,'tools':tools_list(b.get('tools',[])),'tools_top_level':len(b.get('tools',[])),'tools_schema_chars':len(tooltext),'tools_schema_estimate_tokens':tokens(tooltext),'all_text_and_tools_estimate_tokens':tokens(text),'body_json_estimate_tokens':tokens(json.dumps(b,ensure_ascii=False,separators=(',',':')))}

def sse(p):
    out=[]
    for l in p.read_text().splitlines():
        if not l.startswith('data: '):continue
        try:out.append(json.loads(l[6:]))
        except:pass
    return out
def analyze_run(p):
    if not (p/'result.json').exists():return {'name':p.name,'running':True}
    result=json.loads((p/'result.json').read_text());query=result.get('steer_time',float('inf'))
    reqs=[json.loads(f.read_text()) for f in sorted(p.glob('request-*.json'))]
    seen=next((r['time'] for r in reqs if any(content(m.get('content'))=='怎么样了？' for m in r['body'].get('input',r['body'].get('messages',[])) if isinstance(m,dict))),None)
    events=[json.loads(l) for l in (p/'events.jsonl').read_text().splitlines()]
    texts=[];toolcalls=[];turns=[];errors=[];model_tokens=[]
    for d in events:
        e=d['event'];t=d['time'];m=e.get('method','');v=e.get('params',{});ty=e.get('type')
        if m=='item/agentMessage/delta' and v.get('delta'):texts.append({'time':t,'text':v['delta'],'source':'delta'})
        if m=='item/completed' and v.get('item',{}).get('type')=='agentMessage':texts.append({'time':t,'text':v['item'].get('text',''),'source':'complete'})
        if m=='item/started' and v.get('item',{}).get('type') in ['commandExecution','mcpToolCall','dynamicToolCall','plan','collabAgentToolCall','imageView']:toolcalls.append({'time':t,'type':v['item'].get('type')})
        if m=='turn/completed':turns.append({'time':t,'turn':v.get('turn',{}).get('id'),'status':v.get('turn',{}).get('status')})
        if m=='error':errors.append({'time':t,'error':v.get('error',{}).get('message','')})
        if ty=='message_update':
            a=e.get('assistantMessageEvent',{})
            if a.get('type')=='text_delta' and a.get('delta'):texts.append({'time':t,'text':a['delta'],'source':'delta'})
        if ty=='message_end':
            msg=e.get('message',{})
            if msg.get('role')=='assistant' and msg.get('errorMessage'):errors.append({'time':t,'error':msg['errorMessage']})
            if msg.get('role')=='assistant':
                txt='\n'.join(c.get('text','') for c in msg.get('content',[]) if c.get('type')=='text')
                if txt:texts.append({'time':t,'text':txt,'source':'complete'})
        if ty=='tool_execution_start':toolcalls.append({'time':t,'type':e.get('toolName')})
        if ty=='agent_end':turns.append({'time':t,'status':'agent_end'})
        if m=='session.event':
            ev=v.get('event',{});data=ev.get('data',{})
            if ev.get('type')=='assistant/message':
                msg=data.get('message',{});txt='\n'.join(c.get('text','') for c in msg.get('content',[]) if c.get('type')=='text')
                if txt:texts.append({'time':t,'text':txt,'source':'complete'})
            if ev.get('type')=='tool/call':toolcalls.append({'time':t,'type':data.get('name')})
            if ev.get('type')=='turn/end':turns.append({'time':t,'turn':data.get('turn'),'status':'turn/end'})
    for r in reqs:
        f=p/f"response-{r['n']:03d}.txt";ss=sse(f) if f.exists() else []
        completed=next((d.get('response',{}) for d in reversed(ss) if d.get('type')=='response.completed'),None)
        usage=completed.get('usage') if completed else None
        cs=[d.get('item',{}) for d in ss if d.get('type')=='response.output_item.done']
        hasquery=any(content(m.get('content'))=='怎么样了？' for m in r['body'].get('input',[]) if isinstance(m,dict))
        model_tokens.append({'n':r['n'],'phase':'after_query_consumed' if hasquery else 'initial','time':r['time'],'usage':usage,'tool_names':[x.get('name') for x in cs if x.get('type')=='function_call'],'output_text':'\n'.join(content(x.get('content')) for x in cs if x.get('type')=='message'),'request_sha256':sha(p/f"request-{r['n']:03d}.json"),'response_sha256':sha(f) if f.exists() else None})
    calls=[json.loads(l) for l in (p/'nipa-calls.jsonl').read_text().splitlines()] if (p/'nipa-calls.jsonl').exists() else []
    adds=[c['time'] for c in calls if (' '.join(c['argv'][:2]) in ['call download.add','download add'])]
    order=adds[0] if adds else None
    visible=next((x for x in texts if x['time']>=query),None)
    consumed=next((x for x in texts if seen and x['time']>=seen),None)
    first_terminal_after_order=next((t['time'] for t in turns if order and t['time']>=order),None)
    phaseusage={}
    for phase in ['initial','after_query_consumed']:
        us=[x['usage'] for x in model_tokens if x['phase']==phase and x['usage']]
        phaseusage[phase]={'calls_with_usage':len(us),'input_tokens':sum(u.get('input_tokens',0) for u in us),'output_tokens':sum(u.get('output_tokens',0) for u in us),'cached_input_tokens':sum(u.get('input_tokens_details',{}).get('cached_tokens',0) for u in us),'reasoning_tokens':sum(u.get('output_tokens_details',{}).get('reasoning_tokens',0) for u in us)}
    return {'name':p.name,'kind':result.get('kind'),'slim':result.get('slim'),'result':{k:v for k,v in result.items() if 'receipt' not in k},'order_time_actual':order,'order_before_query':bool(order and order<=query),'query_active':result.get('steer_was_active'),'query_delivery_receipt':result.get('steer_receipt'),'query_consumed_time':seen,'delivery_seconds':round(seen-query,3) if seen else None,'first_visible_seconds':round(visible['time']-query,3) if visible else None,'first_visible_after_consumption_seconds':round(consumed['time']-query,3) if consumed else None,'first_visible_text':visible['text'][:700] if visible else None,'post_order_to_first_terminal_seconds':round(first_terminal_after_order-order,3) if order and first_terminal_after_order else None,'total_tool_calls_wire':sum(len(x['tool_names']) for x in model_tokens),'tool_calls_host_events':len(toolcalls),'tool_calls_after_query':sum(len(x['tool_names']) for x in model_tokens if x['time']>=query),'nipa_call_count':len(calls),'download_status_calls':sum('download.status' in c['argv'] or c['argv'][:2]==['download','status'] for c in calls),'phase_tokens':phaseusage,'host_turns':turns,'errors':errors,'http_errors':[{'file':x.name,'sha256':sha(x)} for x in p.glob('http-error-*')],'model_calls':model_tokens,'visible_messages':[x for x in texts if x['source']=='complete'],'raw_hashes':{'events':sha(p/'events.jsonl'),'inputs':sha(p/'inputs.jsonl')}}

def main():
    captures={p.name:request_stats(p/'request-001.json') for p in sorted((ROOT/'runs').glob('capture-*')) if (p/'request-001.json').exists()}
    runs=[analyze_run(p) for p in sorted((ROOT/'runs').glob('behavior-final-*'))]
    summary={'date':'2026-10-20','token_estimate_method':'tiktoken o200k_base surrogate, excludes provider-specific framing; not DeepSeek tokenizer','seed_sha256':sha(pathlib.Path('/Users/sakiko/Desktop/NipaPlay-Reload/assets/next/harness/AGENTS.md')),'captures':captures,'behavior':runs}
    (ROOT/'measurements.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2))
    for n,s in captures.items():print(n,s['instructions_chars'],s['system_developer_chars'],s['tools_schema_estimate_tokens'],s['all_text_and_tools_estimate_tokens'])
    for x in runs:
        print(x['name'], {k:x.get(k) for k in ['running','order_before_query','query_active','delivery_seconds','first_visible_seconds','post_order_to_first_terminal_seconds','total_tool_calls_wire','errors']})
if __name__=='__main__':main()
