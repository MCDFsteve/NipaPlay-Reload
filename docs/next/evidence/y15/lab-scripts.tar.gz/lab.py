import asyncio, json, os, pathlib, shutil, time, threading, urllib.request, urllib.error, tomllib, signal, hashlib, sys
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler

ROOT=pathlib.Path.home()/'.nipa-next/y15'
REPO=pathlib.Path('/Users/sakiko/Desktop/NipaPlay-Reload')
MODEL='deepseek-v4.1-flash'
MINIMAL='你是 Nipa，NipaPlay 中的看片助手。遵循工作目录 AGENTS.md，通过 nipa 操作应用。自然、简短地与用户交流。'

class Endpoint:
    def __init__(self, out, real=False):
        self.out=out; self.real=real; self.requests=[]; self.lock=threading.Lock();self.scenario=None
        if real:
            cfg=tomllib.loads((pathlib.Path.home()/'.codex/config.toml').read_text())
            p=cfg['model_providers']['cpa']; self.base=p['base_url'].rstrip('/')
            self.key=p.get('experimental_bearer_token') or os.environ.get(p.get('env_key',''))
            assert self.key
        owner=self
        class Handler(BaseHTTPRequestHandler):
            def log_message(self,*args): pass
            def do_GET(self):
                b=json.dumps({'object':'list','data':[{'id':MODEL,'object':'model','owned_by':'local'}]}).encode()
                self.send_response(200); self.send_header('Content-Type','application/json'); self.end_headers(); self.wfile.write(b)
            def do_POST(self):
                raw=self.rfile.read(int(self.headers.get('Content-Length','0')))
                try: body=json.loads(raw)
                except: body={}
                with owner.lock:
                    n=len(owner.requests)+1
                    rec={'n':n,'time':time.time(),'path':self.path,'body':body}
                    owner.requests.append(rec)
                    (out/f'request-{n:03d}.json').write_text(json.dumps(rec,ensure_ascii=False,indent=2))
                if owner.real:
                    suffix='/responses' if self.path.endswith('responses') else '/chat/completions'
                    url=owner.base+suffix
                    req=urllib.request.Request(url,raw,{'Content-Type':'application/json','Authorization':'Bearer '+owner.key},method='POST')
                    try:
                        with urllib.request.urlopen(req,timeout=160) as r:
                            self.send_response(r.status); self.send_header('Content-Type',r.headers.get('Content-Type','text/event-stream')); self.end_headers()
                            chunks=[]
                            while chunk:=r.read1(65536):
                                chunks.append(chunk)
                                try:self.wfile.write(chunk);self.wfile.flush()
                                except (BrokenPipeError,ConnectionResetError):break
                            (out/f'response-{n:03d}.txt').write_bytes(b''.join(chunks))
                    except urllib.error.HTTPError as e:
                        data=e.read();(out/f'http-error-{n}.txt').write_bytes(data)
                        self.send_response(e.code);self.end_headers();self.wfile.write(data)
                    except Exception as e:
                        (out/f'network-error-{n}.txt').write_text(type(e).__name__)
                        try:self.send_response(502);self.end_headers()
                        except:pass
                    return
                self.send_response(200);self.send_header('Content-Type','text/event-stream' if body.get('stream') else 'application/json');self.end_headers()
                def send(t,d):
                    self.wfile.write(('event: '+t+'\ndata: '+json.dumps({'type':t,**d},ensure_ascii=False)+'\n\n').encode());self.wfile.flush()
                try:
                    if self.path.endswith('responses'):
                        resp={'id':'resp_y15','object':'response','created_at':int(time.time()),'status':'in_progress','model':MODEL,'output':[]}
                        item={'type':'message','id':'msg_y15','role':'assistant','status':'completed','content':[{'type':'output_text','text':'你好，固定回答。','annotations':[]}]}
                        usage={'input_tokens':100,'output_tokens':10,'total_tokens':110,'input_tokens_details':{'cached_tokens':0},'output_tokens_details':{'reasoning_tokens':0}}
                        if owner.scenario=='tools' and n==1:
                            names=[x.get('name') for x in body.get('tools',[])]
                            name='bash' if 'bash' in names else 'exec_command'
                            args={'command':"python3 -c 'import time; time.sleep(2); print(\"Y15_TOOL_DONE\")'",'description':'Y15 controlled wait'} if name=='bash' else {'cmd':"python3 -c 'import time; time.sleep(2); print(\"Y15_TOOL_DONE\")'",'yield_time_ms':10000}
                            tool={'type':'function_call','id':'fc_y15','call_id':'call_y15','name':name,'arguments':json.dumps(args),'status':'completed'}
                            send('response.created',{'response':resp})
                            send('response.output_item.added',{'output_index':0,'item':{**tool,'arguments':'','status':'in_progress'}})
                            send('response.function_call_arguments.delta',{'item_id':tool['id'],'output_index':0,'delta':tool['arguments']})
                            send('response.function_call_arguments.done',{'item_id':tool['id'],'output_index':0,'arguments':tool['arguments']})
                            send('response.output_item.done',{'output_index':0,'item':tool})
                            send('response.completed',{'response':{**resp,'status':'completed','output':[tool],'usage':usage}})
                            return
                        if body.get('stream'):
                            send('response.created',{'response':resp})
                            send('response.output_item.added',{'output_index':0,'item':{**item,'content':[],'status':'in_progress'}})
                            send('response.content_part.added',{'item_id':item['id'],'output_index':0,'content_index':0,'part':{'type':'output_text','text':'','annotations':[]}})
                            send('response.output_text.delta',{'item_id':item['id'],'output_index':0,'content_index':0,'delta':item['content'][0]['text']})
                            send('response.output_text.done',{'item_id':item['id'],'output_index':0,'content_index':0,'text':item['content'][0]['text']})
                            send('response.content_part.done',{'item_id':item['id'],'output_index':0,'content_index':0,'part':item['content'][0]})
                            send('response.output_item.done',{'output_index':0,'item':item})
                            send('response.completed',{'response':{**resp,'status':'completed','output':[item],'usage':usage}})
                        else:self.wfile.write(json.dumps({**resp,'status':'completed','output':[item],'usage':usage}).encode())
                    else:
                        usage={'prompt_tokens':100,'completion_tokens':10,'total_tokens':110}
                        if body.get('stream'):
                            for delta,reason in [({'role':'assistant','content':'你好，固定回答。'},None),({},'stop')]:
                                chunk={'id':'chatcmpl_y15','object':'chat.completion.chunk','created':int(time.time()),'model':MODEL,'choices':[{'index':0,'delta':delta,'finish_reason':reason}]}
                                if reason:chunk['usage']=usage
                                self.wfile.write(('data: '+json.dumps(chunk,ensure_ascii=False)+'\n\n').encode());self.wfile.flush()
                            self.wfile.write(b'data: [DONE]\n\n')
                        else:self.wfile.write(json.dumps({'id':'chatcmpl_y15','object':'chat.completion','model':MODEL,'choices':[{'index':0,'message':{'role':'assistant','content':'你好，固定回答。'},'finish_reason':'stop'}],'usage':usage}).encode())
                except (BrokenPipeError,ConnectionResetError):pass
        self.server=ThreadingHTTPServer(('127.0.0.1',0),Handler)
        self.server.daemon_threads=True
        self.thread=threading.Thread(target=self.server.serve_forever,daemon=True);self.thread.start()
        self.url=f'http://127.0.0.1:{self.server.server_port}/v1'
    def close(self):self.server.shutdown();self.server.server_close()

def prepare(name):
    out=ROOT/'runs'/name;out.mkdir(parents=True,exist_ok=False)
    work=out/'harness';work.mkdir()
    shutil.copy2(ROOT/'seed/AGENTS.md' if (ROOT/'seed/AGENTS.md').exists() else REPO/'assets/next/harness/AGENTS.md',work/'AGENTS.md')
    for d in ['home','cache','tmp','config','data','codex','pi','dsh','harness/memory','harness/tools','bin']:(out/d).mkdir(exist_ok=True,parents=True)
    (work/'memory/preferences.md').write_text('2026-10-20 实验偏好：默认简体中文字幕、1080p、第一集优先；用户已授权为想看的作品选择唯一可用来源并开始下载。\n')
    (work/'memory/MEMORY.md').write_text('实验环境：唯一可用种子由 ./nipa 的目录提供；下载在后台执行。\n')
    shutil.copy2(ROOT/'fake_nipa.py',work/'nipa');(work/'nipa').chmod(0o755)
    (out/'bin/nipa').symlink_to(work/'nipa')
    (out/'minimal.txt').write_text(MINIMAL)
    (work/'tools/README.md').write_text('离线实验目录。mikan.py 和 discovery.py 接受任意搜索参数，返回唯一已登记来源；api.py、danmaku.py 返回暂无其他数据。不要访问真实片库。\n')
    for name in ['mikan.py','discovery.py','api.py','danmaku.py']:
        (work/'tools'/name).write_text("import subprocess\nsubprocess.run(['./nipa','call','download.sources','{}'])\n")
    # Enforce the user's write boundary for every nested shell and tool process.
    profile='(version 1)\n(allow default)\n(deny file-write*)\n(allow file-write* (subpath '+json.dumps(str(ROOT))+') (literal "/dev/null") (literal "/dev/tty"))\n(deny network*)\n(allow network-inbound (local ip "localhost:*"))\n(allow network-outbound (remote ip "localhost:*"))\n'
    (out/'sandbox.sb').write_text(profile)
    return out,work

def environment(out):
    env={'HOME':str(out/'home'),'PATH':str(out/'bin')+':/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin','TMPDIR':str(out/'tmp'),'XDG_CONFIG_HOME':str(out/'config'),'XDG_CACHE_HOME':str(out/'cache'),'XDG_DATA_HOME':str(out/'data'),'CODEX_HOME':str(out/'codex'),'PI_CODING_AGENT_DIR':str(out/'pi'),'PI_OFFLINE':'1','DSH_HOME':str(out/'dsh'),'NPM_CONFIG_CACHE':str(ROOT/'npm-cache'),'Y15_FAKE_KEY':'local-only','Y15_ROOT':str(out),'NO_COLOR':'1','LANG':'en_US.UTF-8','SHELL':'/bin/bash','NO_PROXY':'127.0.0.1,localhost'}
    return env

class Agent:
    def __init__(self,kind,out,work,endpoint,wire='responses',slim=False):
        self.kind=kind;self.out=out;self.work=work;self.endpoint=endpoint;self.wire=wire;self.slim=slim;self.events=[];self.pending={};self.id=0;self.active=False;self.turn=None;self.sid=None
    async def start(self):
        env=environment(self.out)
        if hasattr(self,'dsh_home'):env['DSH_HOME']=str(self.dsh_home)
        if self.kind=='codex':
            cfg='model = '+json.dumps(MODEL)+'\nmodel_provider = "y15"\nmodel_context_window = 1000000\nmodel_auto_compact_token_limit = 950000\nmodel_reasoning_effort = "medium"\napproval_policy = "never"\nsandbox_mode = "danger-full-access"\ncheck_for_update_on_startup = false\nweb_search = "disabled"\n[features]\nshell_snapshot = false\nmemories = false\n[model_providers.y15]\nname = "Y15 local relay"\nbase_url = '+json.dumps(self.endpoint.url)+'\nwire_api = "responses"\nenv_key = "Y15_FAKE_KEY"\nrequires_openai_auth = false\n'
            (self.out/'codex/config.toml').write_text(cfg)
            if self.out.name.endswith('seed-live'):
                (self.work/'.codex').mkdir(exist_ok=True);(self.work/'hooks').mkdir(exist_ok=True)
                for n in ['config.toml','hooks.json']:shutil.copy2(REPO/'assets/next/harness/.codex'/n,self.work/'.codex'/n)
                shutil.copy2(REPO/'assets/next/harness/hooks/session_start.py',self.work/'hooks/session_start.py')
                shim='''#!/usr/bin/env python3
import pathlib,subprocess,sys
class Client:
    token='y15-local-fixture'
    def call(self,*args):return {}
    def result(self,*args):return {'settings':{'resolution':'1080p','subtitle':'简体中文'},'recent':{'text':'Y15_MEMORY_HOOK_MARKER','omitted':[]}}
def redact(text,*args):return text
if __name__=='__main__':subprocess.run([sys.executable,'''+repr(str(ROOT/'fake_nipa.py'))+''',*sys.argv[1:]])
'''
                (self.work/'nipa').write_text(shim);(self.work/'nipa').chmod(0o755)
                cfg=cfg.replace('shell_snapshot = false','shell_snapshot = false\nhooks = true')+'\n[projects.'+json.dumps(str(self.work))+']\ntrust_level = "trusted"\n'
                (self.out/'codex/config.toml').write_text(cfg)
            cmd=[str(ROOT/'codex-install/node_modules/.bin/codex'),'app-server']
        elif self.kind=='pi':
            api='openai-responses' if self.wire=='responses' else 'openai-completions'
            (self.out/'pi/models.json').write_text(json.dumps({'providers':{'y15':{'baseUrl':self.endpoint.url,'api':api,'apiKey':'${Y15_FAKE_KEY}','models':[{'id':MODEL,'name':MODEL,'reasoning':True,'input':['text'],'contextWindow':1000000,'maxTokens':8192}]}}}))
            (self.out/'pi/settings.json').write_text(json.dumps({'quietStartup':True,'autoCompaction':{'enabled':False},'retry':{'enabled':False},'telemetry':{'enabled':False}}))
            cmd=[str(ROOT/'pi-install/node_modules/.bin/pi'),'--mode','rpc','--provider','y15','--model',MODEL,'--thinking','medium','--offline','--no-extensions','--no-skills','--no-prompt-templates','--no-themes','--no-mcp','--no-approve']
            if self.slim:cmd+=['--system-prompt',str(self.out/'minimal.txt'),'--tools','bash']
            if hasattr(self,'resume_path'):cmd+=['--session',self.resume_path]
            if hasattr(self,'extension_path'):cmd+=['--extension',str(self.extension_path)]
        else:
            cmd=self.dsh_command(env)
        if self.kind=='pi' and self.out.name.endswith('native'):
            cmd[0]=str(ROOT/'pi-native/pi');env['PATH']=str(self.out/'bin')+':/usr/bin:/bin'
        cmd=['/usr/bin/sandbox-exec','-f',str(self.out/'sandbox.sb'),*cmd]
        self.p=await asyncio.create_subprocess_exec(*cmd,cwd=self.work,env=env,stdin=asyncio.subprocess.PIPE,stdout=asyncio.subprocess.PIPE,stderr=asyncio.subprocess.PIPE,start_new_session=True,limit=16*1024*1024)
        self.reader=asyncio.create_task(self.read());self.err=asyncio.create_task(self.stderr())
        if self.kind=='codex':
            await self.rpc('initialize',{'clientInfo':{'name':'y15-research','version':'1'},'capabilities':{'experimentalApi':True}})
            await self.send({'method':'initialized','params':{}})
            params={'cwd':str(self.work),'model':MODEL,'approvalPolicy':'never','sandbox':'danger-full-access'}
            if self.out.name.endswith('seed-live'):
                listed=await self.rpc('hooks/list',{'cwds':[str(self.work)]});states={}
                for group in listed.get('result',{}).get('data',[]):
                    for h in group.get('hooks',[]):
                        if h.get('source')=='project' and h.get('enabled'):states[h['key']]={'trusted_hash':h['currentHash']}
                params['config']={'hooks':{'state':states},'web_search':'live'}
            if self.slim:params['baseInstructions']=MINIMAL
            if self.out.name.endswith('model-file'):params['config']={'model_instructions_file':str(self.out/'minimal.txt')}
            if self.out.name.endswith('web-live'):params['config']={'web_search':'live'}
            if self.out.name.endswith('trim-tools'):
                params['baseInstructions']=MINIMAL
                params['config']={'features.multi_agent':False,'features.goals':False,'features.multi_agent_v2':False}
            r=await self.rpc('thread/start',params);self.sid=r['result']['thread']['id']
        elif self.kind=='dsh':await self.dsh_initialize()
    async def stderr(self):
        with (self.out/'stderr.txt').open('wb') as f:
            while b:=await self.p.stderr.read(8192):f.write(b);f.flush()
    async def read(self):
        with (self.out/'events.jsonl').open('w') as f:
            async for line in self.p.stdout:
                try:d=json.loads(line)
                except: d={'invalid':line.decode(errors='replace')}
                e={'time':time.time(),'event':d};self.events.append(e);f.write(json.dumps(e,ensure_ascii=False)+'\n');f.flush()
                if d.get('id') in self.pending:self.pending.pop(d['id']).set_result(d)
                meth=d.get('method','');params=d.get('params',{})
                if self.kind=='codex':
                    if meth=='turn/started':self.active=True;self.turn=params.get('turn',{}).get('id')
                    if meth=='turn/completed':self.active=False
                elif self.kind=='pi':
                    if d.get('type')=='agent_start':self.active=True
                    if d.get('type')=='agent_settled':self.active=False
                else:self.dsh_event(d)
    async def send(self,d):
        with (self.out/'inputs.jsonl').open('a') as f:f.write(json.dumps({'time':time.time(),'input':d},ensure_ascii=False)+'\n')
        self.p.stdin.write((json.dumps(d,ensure_ascii=False)+'\n').encode());await self.p.stdin.drain()
    async def rpc(self,method,params=None,timeout=30):
        self.id+=1;i=str(self.id);f=asyncio.get_running_loop().create_future();self.pending[i]=f
        d={'id':i,'type':method,**(params or {})} if self.kind=='pi' else {'jsonrpc':'2.0','id':i,'method':method,'params':params or {}}
        await self.send(d);return await asyncio.wait_for(f,timeout)
    async def prompt(self,text,steer=False):
        if self.kind=='codex':
            p={'threadId':self.sid,'input':[{'type':'text','text':text}]}
            if steer:p['expectedTurnId']=self.turn
            r=await self.rpc('turn/steer' if steer else 'turn/start',p)
            if not steer and 'result' in r:self.active=True;self.turn=r['result'].get('turn',{}).get('id')
            return r
        if self.kind=='pi':
            if not steer:self.active=True
            return await self.rpc('steer' if steer else 'prompt',{'message':text})
        return await self.dsh_prompt(text,steer)
    async def stop(self):
        try:
            if self.active:
                if self.kind=='codex':await self.rpc('turn/interrupt',{'threadId':self.sid,'turnId':self.turn},5)
                elif self.kind=='pi':await self.rpc('abort',timeout=5)
            self.p.stdin.close()
            await asyncio.wait_for(self.p.wait(),5)
        except:
            try:os.killpg(self.p.pid,signal.SIGTERM)
            except ProcessLookupError:pass
            try:await asyncio.wait_for(self.p.wait(),3)
            except:
                try:os.killpg(self.p.pid,signal.SIGKILL)
                except ProcessLookupError:pass
        await asyncio.gather(self.reader,self.err,return_exceptions=True)
    async def dsh_initialize(self):
        r=await self.rpc('initialize',{'cwd':str(self.work),'provider':'y15','model':MODEL,'reasoningEffort':'medium','maxTokens':8192},timeout=60)
        if 'error' in r:raise RuntimeError(str(r['error']))
        self.sid='y15-'+self.out.name
    async def dsh_prompt(self,text,steer):
        self.active=True
        return await self.rpc('session/steer' if steer else 'session/prompt',{'sessionId':self.sid,'contentBlocks':[{'type':'text','text':text}]})
    def dsh_event(self,d):
        if d.get('method')=='session.status':self.active=d.get('params',{}).get('status')=='running'
    def dsh_command(self,env):
        env['DSH_PERMISSION_MODE']='danger-full-access';env['DSH_TELEMETRY']='0'
        env['PATH']=str(ROOT/'node-install/node_modules/node/bin')+':'+env['PATH']
        api='openai-responses' if self.wire=='responses' else 'openai-completions'
        route={'providers':{'y15':{'api':api,'baseURL':self.endpoint.url,'apiKeyEnv':'Y15_FAKE_KEY','defaultMaxTokens':8192,'retryPolicy':{'mode':'normal','maxRetries':0},'models':[{'id':MODEL,'contextWindow':1000000,'maxTokens':8192,'reasoningEfforts':{'medium':'medium'}}]}}}
        rows=[{'id':'session-log-deepseek','disabled':True},{'id':'plugin-package-inventory-deepseek','disabled':True}]
        if self.slim:rows.append({'insert':[{'id':'llm-pi-ai','name':'@deepseek-ai/dsh-llm-pi-ai','config':route}]})
        else:rows.append({'id':'llm-pi-ai','config':route})
        if self.out.name.endswith('minimal-seed'):rows.append({'insert':[{'id':'agent-instructions','name':'@deepseek-ai/dsh-agent-instructions','config':{'maxBytes':65536,'instructionFileCandidates':['AGENTS.md']}}]})
        if self.out.name.startswith(('behavior-','probe-')):
            rows += [{'id':'sdk-jsonrpc-server','disabled':True},{'insert':[{'id':'y15-control','name':str(ROOT/'dsh-install/y15-bridge.mjs')}]}]
        # JSON is valid YAML, avoiding a YAML dependency in the lab driver.
        patch=self.out/'dsh-patch.yaml';patch.write_text(json.dumps(rows,ensure_ascii=False,indent=2))
        return [str(ROOT/'node-install/node_modules/node/bin/node'),str(ROOT/'dsh-install/node_modules/@deepseek-ai/dsh/lib/bin.js'),'--profile','sdk-minimal' if self.slim else 'sdk','--patch',str(patch)]

async def capture(kind,name,wire='responses',slim=False):
    out,work=prepare(name);e=Endpoint(out);a=Agent(kind,out,work,e,wire,slim)
    try:
        await a.start();await a.prompt('你好')
        start=time.time()
        while time.time()-start<45:
            if e.requests and not a.active:break
            if a.p.returncode is not None:break
            await asyncio.sleep(.1)
        result={'kind':kind,'wire':wire,'slim':slim,'requests':len(e.requests),'active':a.active}
    except Exception as ex:result={'error':repr(ex)}
    finally:
        if hasattr(a,'p'):await a.stop()
        e.close()
    (out/'result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print(name,result,flush=True)

async def behavior(kind,name,slim=False):
    out,work=prepare(name);e=Endpoint(out,real=True);a=Agent(kind,out,work,e,'responses',slim)
    result={'kind':kind,'slim':slim,'model':MODEL,'wire':'responses','deadline_seconds':240,'interrupt_delay_seconds':2}
    try:
        await a.start();result['start_time']=time.time();result['initial_receipt']=await a.prompt('我想看《孤独摇滚！》')
        start=time.time()
        while time.time()-start<120:
            if (out/'download.json').exists():
                result['order_time']=json.loads((out/'download.json').read_text())['started']
                await asyncio.sleep(2);break
            if not a.active or a.p.returncode is not None:break
            await asyncio.sleep(.1)
        result['steer_time']=time.time();result['steer_was_active']=a.active
        result['steer_receipt']=await a.prompt('怎么样了？',steer=a.active)
        start=time.time()
        while time.time()-start<120:
            if not a.active or a.p.returncode is not None:break
            await asyncio.sleep(.1)
        result['end_time']=time.time();result['active_at_deadline']=a.active;result['requests']=len(e.requests)
    except Exception as ex:result['error']=type(ex).__name__+': '+str(ex)[:300]
    finally:
        if hasattr(a,'p'):await a.stop()
        e.close()
    (out/'result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print(name,{k:v for k,v in result.items() if k not in ['initial_receipt','steer_receipt']},flush=True)

if __name__=='__main__':
    if sys.argv[1]=='behavior':asyncio.run(behavior(*sys.argv[2:4],slim='slim' in sys.argv))
    else:asyncio.run(capture(*sys.argv[1:3],wire=sys.argv[3] if len(sys.argv)>3 else 'responses',slim='slim' in sys.argv))
