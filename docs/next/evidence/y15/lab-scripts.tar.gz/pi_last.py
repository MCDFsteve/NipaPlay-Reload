import asyncio
from lab import ROOT,behavior
async def main():
    while not (ROOT/'runs/behavior-final-codex-slim-6/result.json').exists():await asyncio.sleep(1)
    await behavior('pi','behavior-final-pi-5')
asyncio.run(main())
