import asyncio
from lab import ROOT,behavior
async def main():
    while not (ROOT/'runs/behavior-final-codex-4/result.json').exists():await asyncio.sleep(1)
    await behavior('codex','behavior-final-codex-slim-6',slim=True)
asyncio.run(main())
