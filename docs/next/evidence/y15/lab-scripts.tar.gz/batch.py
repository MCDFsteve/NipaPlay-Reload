import asyncio
from lab import behavior
async def main():
    for index in range(1,4):
        await asyncio.gather(*[
            behavior('codex',f'behavior-final-codex-{index}'),
            behavior('codex',f'behavior-final-codex-slim-{index}',slim=True),
            behavior('pi',f'behavior-final-pi-{index}'),
            behavior('dsh',f'behavior-final-dsh-{index}'),
        ])
asyncio.run(main())
