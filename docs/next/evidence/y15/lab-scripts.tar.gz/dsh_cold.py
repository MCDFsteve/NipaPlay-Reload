import asyncio,json,time
from lab import ROOT,prepare,Endpoint,Agent
async def main():
    out,work=prepare('probe-dsh-cold-resume');ep=Endpoint(out);a=Agent('dsh',out,work,ep);a.dsh_home=ROOT/'runs/probe-dsh-steer/dsh';result={}
    try:
        await a.start();a.sid='y15-probe-dsh-steer'
        result['resume']=await a.rpc('session/resume',{'sessionId':a.sid})
        result['historical_events_replayed']=sum(x['event'].get('method')=='session.event' for x in a.events)
        await a.prompt('Y15_AFTER_COLD_RESUME')
        for _ in range(200):
            if ep.requests and not a.active:break
            await asyncio.sleep(.02)
        result['requests']=len(ep.requests)
        result['history_marker_retained']='Y15_STEER_MARKER' in json.dumps(ep.requests[-1]['body']) if ep.requests else False
    except Exception as e:result['error']=repr(e)
    finally:
        if hasattr(a,'p'):await a.stop()
        ep.close()
    (out/'protocol-result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print(result)
asyncio.run(main())
