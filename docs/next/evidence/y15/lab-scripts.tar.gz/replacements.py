import asyncio
from lab import ROOT,behavior
async def main():
    while not (ROOT/'runs/behavior-final-codex-slim-5/result.json').exists():await asyncio.sleep(1)
    await behavior('pi','behavior-final-pi-4')
    await behavior('codex','behavior-final-codex-4')
asyncio.run(main())
