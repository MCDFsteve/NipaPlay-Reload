import asyncio,json,pathlib,time,sys
from lab import ROOT,prepare,Endpoint,Agent
async def settle(a):
    for _ in range(200):
        if not a.active:return
        await asyncio.sleep(.02)
async def main():
    long='--long' in sys.argv
    out,work=prepare('probe-pi-compaction' if long else 'probe-pi-memory-resume');ep=Endpoint(out)
    extension=out/'memory-extension.ts'
    extension.write_text('''import fs from "node:fs";
import path from "node:path";
export default function(pi) {
  pi.on("context", (event, ctx) => {
    const memory = ["preferences.md","MEMORY.md"].map(n => fs.readFileSync(path.join(ctx.cwd,"memory",n),"utf8")).join("\\n");
    return {messages:[...event.messages,{role:"user",content:[{type:"text",text:"Nipa memory context:\\n"+memory}],timestamp:Date.now()}]};
  });
}
''')
    (work/'memory/preferences.md').write_text('Y15_MEMORY_REV_ONE\n')
    result={};a=Agent('pi',out,work,ep);a.extension_path=extension
    try:
        await a.start();await a.prompt('你好');await settle(a)
        if long:
            for i in range(3):
                await a.prompt('Y15_FILLER_'+str(i)+'\n'+('填充上下文。'*10000));await settle(a)
        state=await a.rpc('get_state');result['initial_state']=state
        sessionpath=state.get('data',{}).get('sessionFile')
        assert sessionpath, str(state)
        before=len(ep.requests);result['compact']=await a.rpc('compact',{},timeout=20)
        result['compaction_model_calls']=len(ep.requests)-before
        (work/'memory/preferences.md').write_text('Y15_MEMORY_REV_TWO\n')
        await a.prompt('压缩后你好');await settle(a)
        result['after_compact_new_memory']='Y15_MEMORY_REV_TWO' in json.dumps(ep.requests[-1]['body'])
        await a.stop()
        (out/'events.jsonl').rename(out/'first-process-events.jsonl');(out/'inputs.jsonl').rename(out/'first-process-inputs.jsonl')
        a=Agent('pi',out,work,ep);a.extension_path=extension;a.resume_path=sessionpath
        await a.start();result['resumed_state']=await a.rpc('get_state');result['resumed_messages']=await a.rpc('get_messages')
        await a.prompt('恢复后你好');await settle(a)
        result['cold_resume_new_memory']='Y15_MEMORY_REV_TWO' in json.dumps(ep.requests[-1]['body'])
        result['same_session_id']=result['initial_state'].get('data',{}).get('sessionId')==result['resumed_state'].get('data',{}).get('sessionId')
        result['requests']=len(ep.requests)
    except Exception as ex:result['error']=repr(ex)
    finally:
        if hasattr(a,'p'):await a.stop()
        ep.close()
    (out/'protocol-result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print({k:v for k,v in result.items() if k not in ['initial_state','resumed_state','resumed_messages']})
asyncio.run(main())
